import java.applet.Applet;
import java.awt.Graphics;

class LineApplet extends Applet throws Exception{

    public void paint(Graphics g) {
        // Draw a line from (10, 10) to (200, 200)
        g.drawLine(10, 10, 200, 200);
    }
}
