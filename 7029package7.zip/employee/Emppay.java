import java.io.*;
import employee.Emp;
class Emppay
{

 public static void main(String args[])
 {

   Emp e = new Emp("Samiksha","27","Female",15000);
   e.call();
   e.display();
   }
 }
